from django.db.models import manager
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework import serializers

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import UserSerailizer
from .models import users

# Create your views here.
@api_view(['GET'])
def list(request):
    user = users.objects.all()
    serializer = UserSerailizer(user, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def detail(request,pk):
    user = users.objects.get(id=pk)
    serializer = UserSerailizer(user, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def update(request,pk):
    user = users.objects.get(id=pk)
    serializer = UserSerailizer(instance=user, data=request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['POST'])
def post(request):
    serializer = UserSerailizer(data=request.data, many=False)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['DELETE'])
def delete(request,pk):
    user = users.objects.get(id=pk)
    user.delete()
    return Response('deleted sucess')
